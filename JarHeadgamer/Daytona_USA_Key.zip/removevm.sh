#!/bin/sh
# ------------------------------------------------------------------
# source name: removevm.sh
# contents�� remove VMS and VMS files that create 2 days before
# comment
# history
#    new create 2000/1/18 --- ISAO Co. J.Tanaka
#    Added MATCH_NOTHING_DEFAULT_PAD for the case where no files
#      have been accessed in last day, to prevent egrep error
#      on null regex
# ------------------------------------------------------------------

##### directory ############################################

cd /web/daytona/htdocs/key/vm_data/data/

##### start ################################################

echo "--- START PROCESS [removevm.sh] ---`date +\"%Y/%m/%d %p %I:%M:%S\"`---"

# find "*.VMI" or "*.VMS" files which was accessed within 1 days ago.
# put them in templist file.
find . -name "*.VMS" -atime 0 | sed 's/.\///g' > templist
find . -name "*.VMI" -atime 0 | sed 's/.\///g' >> templist
find . -name "*.VMS" -atime 1 | sed 's/.\///g' >> templist
find . -name "*.VMI" -atime 1 | sed 's/.\///g' >> templist

# create string from templist
# ex) [aaa.VMS|aaa.VMI|bbb.VMS|bbb.VMI]
filename="MATCH_NOTHING_DEFAULT_PAD"
for name in `cat templist`
do
        filename=$filename"|"$name
done
filename=`echo $filename | sed 's/|//1'`
# echo $filename

# extract remove files and put them in dellist
ls | egrep "VMS|VMI" | egrep -v "$filename" > dellist

# remove files which listed in dellist file
for name in `cat dellist`
do
	lname=`ls -l $name`
	echo "file remove:"$lname
	rm $name
done

# remove temp files
rm templist
rm dellist

echo "--- END PROCESS [removevm.sh] ---`date +\"%Y/%m/%d %p %I:%M:%S\"`---"

# end
