﻿=== Paper Mario Color Splash Cursor Set ===

By: Cocojuju (http://www.rw-designer.com/user/63772)

Download: http://www.rw-designer.com/cursor-set/paper-mario-color-splash

Author's description:

The first Paper Mario Color Splash cursor set.

==========

License: Released to Public Domain

You are free:

* To use this work for any legal purpose.