Aikon Squared (Aikon2) LCD Pro by Justin 'juzmental' Trevena.

Release Version

- Fixed Metacontact text (so it's not always bold)
- Fixed History Text colour
- Added popup and checkmark to menus
- Added pics to the systray alerts
- Reduced size of the systray alerts
- Fixed template buttons (still an issue in the AIM user profile screen though)
- New set of emoticons. Aikon LCD Emoticons.
- Made the group headers (My Mail etc) darker
- Changed the menu bar in the contact list to be in reverse
- Can't remember the rest. :)

Beta

- Was a quick and dirty "add what I can" of Trillian Pro's features to get something out there. Had a lot of things that weren't right.
